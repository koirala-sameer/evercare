import React from "react";
import { Routes, Route } from "react-router-dom";

import Home from "../pages/Home";
import Pricing from "../pages/Pricing";
import Security from "../pages/Security";
import AddOns from "../pages/AddOns";  // ← NEW PAGE

export default function AppRoutes() {
  return (
    <Routes>
      {/* MAIN ROUTES */}
      <Route path="/" element={<Home />} />
      <Route path="/pricing" element={<Pricing />} />
      <Route path="/security" element={<Security />} />

      {/* NEW ADD-ON BUILDER PAGE */}
      <Route path="/addons" element={<AddOns />} />
    </Routes>
  );
}
