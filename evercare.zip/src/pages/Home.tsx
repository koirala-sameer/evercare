import React from "react";
import Hero from "../sections/Hero/Hero";
import Features from "../sections/Features/Features";
import Services from "../sections/Services/Services";
import Pricing from "../sections/Pricing/Pricing";

export default function Home() {
  return (
    <>
      <Hero />
      <Features />
      <Services />
      <Pricing />
    </>
  );
}
