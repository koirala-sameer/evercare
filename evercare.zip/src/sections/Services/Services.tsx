import React from "react";

const tabs = [
  "Outdoor",
  "Break-in",
  "Smoke & CO",
  "Water",
  "Temp",
  "Deliveries",
];

const steps = [
  {
    icon: "https://img.icons8.com/?size=512&id=11653&format=png",
    text: "AI-powered camera alerts the monitoring center of a possible threat on your property.",
  },
  {
    icon: "https://img.icons8.com/?size=512&id=59813&format=png",
    text: "In less than 30 sec, an agent can assess and react based on the situation.",
  },
  {
    icon: "https://img.icons8.com/?size=512&id=38432&format=png",
    text: "Agents can speak, sound the siren, and trigger the spotlight to deter the potential intruder.",
  },
  {
    icon: "https://img.icons8.com/?size=512&id=86981&format=png",
    text: "Agents can request priority police dispatch with video verification of a crime in progress.",
  },
  {
    icon: "https://img.icons8.com/?size=512&id=59839&format=png",
    text: "You’re notified of the agent’s actions, and you can review recordings in your app.",
  },
];

const Services = () => {
  return (
    <section className="w-full bg-white py-28">
      <div className="max-w-6xl mx-auto px-6 text-center">

        {/* Title */}
        <h2 className="text-4xl md:text-5xl font-bold text-[#0c1b33] mb-4">
          Prevent crime before it happens
        </h2>

        {/* Subtitle */}
        <p className="text-lg text-gray-600 mb-10">
          AI-powered cameras + a team of monitoring agents work together to help deter criminals*
        </p>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {tabs.map((t, i) => (
            <button
              key={t}
              className={`px-6 py-2.5 rounded-full border text-sm font-medium transition ${
                i === 0
                  ? "bg-blue-600 text-white border-blue-600 shadow-md"
                  : "bg-white text-blue-700 border-blue-300 hover:bg-blue-50"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Main Illustration */}
        <div className="flex justify-center mb-14">
          <img
            src="https://i.ibb.co/S5zszq0/simplisafe-illustration.png"
            alt="Monitoring Scene"
            className="w-full max-w-3xl rounded-xl"
          />
        </div>

        {/* Steps Section */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">

          {steps.map((s) => (
            <div
              key={s.text}
              className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col items-center text-center"
            >
              <img src={s.icon} alt="icon" className="h-10 w-10 mb-4 opacity-80" />
              <p className="text-sm text-[#0c1b33] leading-relaxed">{s.text}</p>
            </div>
          ))}

        </div>

        {/* Disclaimer */}
        <p className="text-xs text-gray-400 mt-8">
          *Requires a monitoring plan • **Video verification speeds up police response**
        </p>
      </div>
    </section>
  );
};

export default Services;
