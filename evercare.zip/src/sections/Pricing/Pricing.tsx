import React from "react";

const Pricing = () => {
  return (
    <section className="relative w-full py-32 bg-gradient-to-b from-white via-[#f8faff] to-white overflow-hidden">

      {/* Ambient lights */}
      <div className="absolute top-[-200px] right-[-150px] w-[550px] h-[550px] 
        bg-[radial-gradient(circle,rgba(99,102,241,0.18)_0%,transparent_70%)] 
        blur-3xl opacity-50"></div>

      <div className="absolute bottom-[-200px] left-[-150px] w-[550px] h-[550px] 
        bg-[radial-gradient(circle,rgba(52,211,153,0.18)_0%,transparent_70%)] 
        blur-3xl opacity-50"></div>

      <div className="relative max-w-6xl mx-auto px-6 z-20">

        {/* Heading */}
        <div className="text-center mb-16">
          <h2 className="text-5xl font-extrabold text-gray-900 tracking-tight mb-4">
            One Simple Plan That Protects Everything
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            No confusion. No complicated tiers.  
            Start with Guardian Secure — then customize your care plan.
          </p>
        </div>

        {/* Main Pricing Card */}
        <div className="max-w-3xl mx-auto">

          <div className="bg-white/60 backdrop-blur-2xl rounded-3xl p-12 
            border border-white/40 shadow-[0_25px_80px_rgba(0,0,0,0.08)]
            hover:shadow-[0_35px_110px_rgba(0,0,0,0.12)] transition-all duration-500">

            {/* Title */}
            <h3 className="text-3xl font-bold text-gray-900 text-center mb-4">
              Guardian Secure
            </h3>

            {/* Price */}
            <div className="text-center mb-2">
              <span className="text-6xl font-extrabold bg-gradient-to-r 
                from-blue-600 to-blue-400 text-transparent bg-clip-text">
                $9.99
              </span>
              <span className="text-gray-600 text-xl ml-1">/month</span>
            </div>

            <p className="text-center text-gray-500 mb-8">
              One-time setup: $129
            </p>

            {/* Tagline */}
            <p className="text-center italic text-gray-700 font-medium mb-10 text-lg">
              “Your home and parents — always protected.”
            </p>

            {/* Feature List */}
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10 text-gray-700">
              {[
                "Smart Camera + Door/Window Sensors",
                "Panic Button for Parents",
                "24/7 Monitoring & Emergency Alerts",
                "Weekly Parent Wellbeing Check-in",
                "Home Status Report Every Week",
                "Police/Neighbor Escalation",
                "Home Power/Internet Monitoring",
                "Smoke/CO2 integration (Phase 2)",
                "Mobile App (Live View + Alerts)",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-1 h-2.5 w-2.5 rounded-full bg-blue-500"></span>
                  {item}
                </li>
              ))}
            </ul>

            {/* CTA */}
            <div className="text-center">
              <button
                className="bg-blue-600 text-white px-12 py-4 rounded-2xl text-lg font-semibold 
                shadow-lg hover:bg-blue-700 hover:shadow-xl transition-all duration-300"
              >
                Build Your Care Plan →
              </button>
            </div>

            {/* Subtitle under CTA */}
            <p className="text-center text-gray-500 text-sm mt-5">
              Add optional services like health support, home assistance,  
              or full concierge care — only if you need them.
            </p>

          </div>
        </div>

      </div>
    </section>
  );
};

export default Pricing;
