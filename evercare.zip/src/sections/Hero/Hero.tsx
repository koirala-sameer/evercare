import React from "react";

const Hero = () => {
  return (
    <section className="relative w-full bg-[#f8f9fa] overflow-hidden">

      {/* Floating radial gradients */}
      <div className="absolute w-[600px] h-[600px] top-[-200px] right-[-100px] rounded-full bg-[radial-gradient(circle,rgba(66,133,244,0.1)_0%,transparent_70%)] animate-pulse"></div>
      <div className="absolute w-[500px] h-[500px] bottom-[-150px] left-[-100px] rounded-full bg-[radial-gradient(circle,rgba(52,168,83,0.08)_0%,transparent_70%)] animate-pulse"></div>

      <div className="max-w-7xl mx-auto px-6 pt-24 pb-20 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center relative z-10">

        {/* LEFT CONTENT */}
        <div>

          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/90 backdrop-blur px-5 py-2.5 rounded-full text-sm font-semibold text-blue-600 shadow-md mb-10 border border-gray-100">
            <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
            Trusted by 50,000+ Diaspora Families
          </div>

          {/* Heading */}
          <h1 className="text-[56px] md:text-[64px] font-bold leading-[1.1] text-[#202124] mb-6 tracking-tight">
            Smart Home Security <br /> Base Package
          </h1>

          {/* Subtitle */}
          <p className="text-[20px] text-[#666] leading-relaxed max-w-xl mb-12">
            A simple, standardized starter product that unlocks everything else.
            Non-negotiable base offering designed for diaspora families.
          </p>

          {/* Price Box */}
          <div className="inline-flex items-baseline gap-3 bg-white px-12 py-7 rounded-2xl shadow-2xl border border-gray-100 mb-10">
            <span className="text-[52px] md:text-[56px] font-bold text-blue-600">$9.99</span>
            <span className="text-gray-500 text-[20px] font-medium">/month</span>
          </div>

          {/* Buttons */}
          <div className="flex flex-wrap gap-4 mb-12">
            <button className="bg-blue-600 text-white px-10 py-3.5 rounded-xl text-[17px] font-semibold shadow-lg hover:-translate-y-1 hover:shadow-xl transition">
              Get Started →
            </button>

            <button className="bg-white border-2 border-blue-600 text-blue-600 px-10 py-3.5 rounded-xl text-[17px] font-semibold hover:bg-blue-600 hover:text-white hover:-translate-y-1 transition">
              Watch Demo
            </button>
          </div>

          {/* Feature Items */}
          <div className="flex flex-wrap gap-12">
            {[
              "Professional Installation",
              "24/7 Monitoring",
              "No Contracts",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 text-gray-700 text-[15px] font-medium">
                <span className="flex items-center justify-center h-6 w-6 rounded-full bg-green-500 text-white text-[14px] font-bold">✓</span>
                {item}
              </div>
            ))}
          </div>

        </div>

        {/* RIGHT — PHONE MOCKUP */}
        <div className="flex justify-center">

          {/* Phone outer shell */}
          <div className="relative bg-[#1a1a1a] w-[340px] h-[680px] rounded-[40px] shadow-[0px_40px_80px_rgba(0,0,0,0.3)] p-3">

            {/* Phone notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-black h-8 w-40 rounded-b-3xl z-20"></div>

            {/* Screen */}
            <div className="bg-[#5597f0] w-full h-full rounded-[32px] p-6 text-white flex flex-col">

              <div className="text-sm opacity-90 mt-6">Today, 2:47 PM</div>
              <div className="text-[26px] font-bold mt-1">Home Status</div>
              <div className="opacity-90 mb-4">All systems operational</div>

              {/* Feature Grid */}
              <div className="grid grid-cols-2 gap-4 mt-4">

                {/* Card 1 */}
                <div className="bg-[#7aafff]/30 backdrop-blur rounded-xl p-4">
                  <img
                    src="https://img.icons8.com/?size=512&id=59867&format=png"
                    className="h-8 mb-2"
                  />
                  <div className="font-semibold text-[15px]">Live Camera</div>
                  <div className="text-xs opacity-90">• Recording</div>
                </div>

                {/* Card 2 */}
                <div className="bg-[#7aafff]/30 backdrop-blur rounded-xl p-4">
                  <span className="text-3xl">❓❓❓</span>
                  <div className="font-semibold text-[15px] mt-2">Front Door</div>
                  <div className="text-xs opacity-90">• Secured</div>
                </div>

                {/* Card 3 */}
                <div className="bg-[#7aafff]/30 backdrop-blur rounded-xl p-4">
                  <span className="text-4xl">💚</span>
                  <div className="font-semibold text-[15px] mt-2">Wellbeing</div>
                  <div className="text-xs opacity-90">• All Good</div>
                </div>

                {/* Card 4 */}
                <div className="bg-[#7aafff]/30 backdrop-blur rounded-xl p-4">
                  <span className="text-4xl">🆘</span>
                  <div className="font-semibold text-[15px] mt-2">Panic Button</div>
                  <div className="text-xs opacity-90">• Ready</div>
                </div>

              </div>

              {/* Footer button */}
              <button className="mt-auto bg-white text-blue-600 font-semibold py-3 rounded-xl shadow text-center">
                View All Cameras →
              </button>

            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default Hero;
