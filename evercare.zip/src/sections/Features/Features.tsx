import React from "react";

const features = [
  {
    title: "24/7 Live Camera Monitoring",
    desc: "Crystal-clear HD live video, night vision, and instant remote access — always know what’s happening at home.",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        strokeWidth={1.5}
        stroke="url(#grad1)"
        className="w-12 h-12 mx-auto mb-4"
      >
        <defs>
          <linearGradient id="grad1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#6366f1" />
          </linearGradient>
        </defs>
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M2.25 12l8.954-8.955c.44-.439 1.152-.128 1.152.488V6.75c4.172 0 7.5 3.327 7.5 7.5 0 
             .89-.154 1.744-.436 2.53-.184.52-.955.613-1.316.153A7.478 7.478 0 0015 
             14.25h-2.643v3.217c0 .616-.713.927-1.152.488L2.25 12z"
        />
      </svg>
    ),
  },
  {
    title: "Instant Alerts & Smart Detection",
    desc: "AI-powered alerts notify you instantly of people, motion, or unusual activity — without false alarms.",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        strokeWidth={1.5}
        viewBox="0 0 24 24"
        stroke="url(#grad2)"
        className="w-12 h-12 mx-auto mb-4"
      >
        <defs>
          <linearGradient id="grad2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#14b8a6" />
            <stop offset="100%" stopColor="#0ea5e9" />
          </linearGradient>
        </defs>
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M14.25 9.75L21 3m0 0h-5.25M21 3v5.25M9.75 
           14.25L3 21m0 0h5.25M3 21v-5.25"
        />
      </svg>
    ),
  },
  {
    title: "Wellbeing & SOS Protection",
    desc: "Perfect for elderly parents — daily wellbeing status and an emergency SOS button for immediate help.",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        strokeWidth={1.5}
        viewBox="0 0 24 24"
        stroke="url(#grad3)"
        className="w-12 h-12 mx-auto mb-4"
      >
        <defs>
          <linearGradient id="grad3" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#22c55e" />
            <stop offset="100%" stopColor="#16a34a" />
          </linearGradient>
        </defs>
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M4.5 12.75l6 6 9-13.5"
        />
      </svg>
    ),
  },
];

const Features = () => {
  return (
    <section className="relative w-full py-32 bg-gradient-to-b from-white via-[#f6f8ff] to-[#eef2ff] overflow-hidden">

      {/* Ambient gradient blobs */}
      <div className="absolute top-[-180px] right-[-150px] w-[500px] h-[500px] bg-[radial-gradient(circle,rgba(66,133,244,0.12)_0%,transparent_70%)] blur-3xl opacity-60"></div>
      <div className="absolute bottom-[-180px] left-[-180px] w-[450px] h-[450px] bg-[radial-gradient(circle,rgba(52,168,83,0.10)_0%,transparent_70%)] blur-3xl opacity-60"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-20">

        {/* Section Header */}
        <div className="text-center mb-20">
          <h2 className="text-5xl font-bold text-gray-900 tracking-tight mb-4">
            Everything You Need to Protect Your Home
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Beautifully engineered home security — combining advanced AI, wellbeing monitoring,  
            and seamless real-time protection designed for families living abroad.
          </p>
        </div>

        {/* Premium Illustration */}
        <div className="flex justify-center mb-24">
          <img
            src="https://i.ibb.co/1XFt4wZ/home-security-illustration.png"
            alt="Security Illustration"
            className="w-full max-w-4xl drop-shadow-2xl rounded-[32px]"
          />
        </div>

        {/* Apple-Style Glass Panels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">

          {features.map((f) => (
            <div
              key={f.title}
              className="bg-white/60 backdrop-blur-xl p-10 rounded-3xl border border-white/40 shadow-[0_20px_60px_rgba(0,0,0,0.08)]
              hover:shadow-[0_30px_80px_rgba(0,0,0,0.12)] hover:-translate-y-1 transition-all duration-500"
            >
              {f.icon}

              <h3 className="text-2xl font-semibold text-gray-900 text-center mb-3">
                {f.title}
              </h3>

              <p className="text-gray-600 text-center leading-relaxed text-[17px]">
                {f.desc}
              </p>
            </div>
          ))}

        </div>
      </div>
    </section>
  );
};

export default Features;
